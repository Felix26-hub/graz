# BOT GRASS AUTO FARMING
- https://t.me/AirdropFamilyIDN
# Update Grass Python
# Register
- https://app.getgrass.io/register/?referralCode=AYtNN0N1D0pzSCc
- Lite Version
- Node Version
- Format Proxy Dah Ane Kasih Contoh Di ```localproxies.txt```
- Pake Salah Satu Saja, Jika Mau Pake Versi Lite Ya Login Extensi Lite, Kalau Mau Pake Node Ya Login Extensi Node
- ```Dashboard Grass Masih Error``` Kata Team Grass Gw Tanyain Didiscord Tadi, Point Bakal Tetep Masuk.

# Requirements

```
git clone https://github.com/AirdropFamilyIDN-V2-0/grass.git
```
```
cd grass
```
```
pip install -r requirements.txt
```
```
python localgrassnode.py
```
```
python localgrasslite.py
```
# How to get userid grass
- login ke web grass , terus inspect / f12 ,  klik console
- paste
``` 
localStorage.getItem('userId')
```
- kalau ga bisa paste ketik ```allow pasting``` enter
- baru paste ```localStorage.getItem('userId')```enter lagi
